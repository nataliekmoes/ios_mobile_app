//
//  MainViewController.swift
//  CSE335_Project
//
//

import UIKit


class MainViewController: UITabBarController {
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
         
    }
}
